package funciones

import (
	"fmt"
)

// Saludar .
func Saludar(name string) {
	fmt.Println("Hola", name)
}

// Despedirse .
func Despedirse(name string) {
	fmt.Println("Adios", name)
}
