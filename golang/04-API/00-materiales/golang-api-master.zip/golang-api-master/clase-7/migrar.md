# Archivos a migrar

## Handler

[x] login.login()
- person:
    [x] create()
    [x] update()
    [x] delete()
    [x] getByID()
    [x] getAll()
[x] response.responseJSON() (borrar)
- route
    [x] RoutePerson()
    [x] RouteLogin()

## Middleware

[x] Log() (borrar)
[x] Authentication()
[x] forbidden() (borrar)

## CMD

[x] Registar con echo. 