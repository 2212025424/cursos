# golang-api
Curso de APIs con Go

## Clase 3 - Creación de una API (CRUD)

Crearemos una API con lo necesario para cumplir con las siglas CRUD (Create, Read, Update, Delete).
