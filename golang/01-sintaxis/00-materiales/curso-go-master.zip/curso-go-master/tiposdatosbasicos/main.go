package main

import "fmt"

func main() {
	// bool, string, numeric
	var a bool

	fmt.Printf("%v", a)
}
