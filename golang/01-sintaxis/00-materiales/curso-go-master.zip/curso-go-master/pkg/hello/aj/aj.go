package aj

func Aj() string {
	return "AJ"
}
