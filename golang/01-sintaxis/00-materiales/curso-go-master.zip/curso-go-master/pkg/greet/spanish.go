package greet

func Spanish() string {
	return "Hola " + emoji
}
