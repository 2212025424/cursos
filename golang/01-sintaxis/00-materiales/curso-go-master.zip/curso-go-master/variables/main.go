package main

import "fmt"

func main() {
	dog, cat := "🐕", "🐈"
	cat, face := "gato", "😋"

	fmt.Println(dog, cat, face)
}
