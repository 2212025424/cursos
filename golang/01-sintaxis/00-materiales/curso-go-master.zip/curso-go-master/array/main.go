package main

import "fmt"

func main() {
	/* 	var food [3]string
	   	food[0] = "🍔"
	   	food[1] = "🍕"
	   	food[2] = "🌭"
	   	food[3] = "🍟" */

	/* 	food := [3]string{
		"🍔",
		"🌭",
		"🍕",
	} */

	var nums [3]int
	nums[1] = 7
	fmt.Println(nums)
}
