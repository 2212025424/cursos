* ¿Qúe son? 
    * Slice no poseen datos, son apuntadores a un Array. 
    * [low: high]
    * default indices
* len(): # de elementos en el slice
* cap(): # de elementos del array donde apunta el slice, a partir del índice de donde se creó el slice
* Slice literales
* Zero value len() = 0 cap() = 0
* make()
* append() capacidad doble