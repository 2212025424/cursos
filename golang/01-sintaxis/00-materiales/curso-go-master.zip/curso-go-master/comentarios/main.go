// package main es el paquete principal
// que me permite ejecutar mi aplicación
// de EDteam
package main

// Test es una variable de prueba
var Test = 123

// Pi es una constante que vale 3.14
const Pi = 3.14

/* func main() {

}
*/
