package clase3

type Perro struct {
	Name string
	Age  uint
	Kind Kind
}

type Kind struct {
	Name string
}
