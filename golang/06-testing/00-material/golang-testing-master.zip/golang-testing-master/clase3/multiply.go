package clase3

func multiply(a, b int) int {
	return a * b
}

func Multiply(a, b int) int {
	return multiply(a, b)
}
