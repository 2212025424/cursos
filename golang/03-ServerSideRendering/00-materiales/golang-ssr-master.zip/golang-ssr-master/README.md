# golang-ssr
Curso de server side rendering con Go
