CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `mauro`@`localhost` 
    SQL SECURITY DEFINER
VIEW `full_article` AS
    SELECT 
        `a`.`sku` AS `sku`,
        `a`.`description` AS `description`,
        `ac`.`description` AS `category`,
        IFNULL(CURRENTSTOCK(`a`.`id`), 0) AS `stock`
    FROM
        (`article` `a`
        JOIN `article_category` `ac` ON ((`ac`.`id` = `a`.`article_category_id`)))