CREATE DEFINER=`mauro`@`localhost` TRIGGER `preventOverSales` BEFORE INSERT ON `stock_movement` FOR EACH ROW BEGIN
	DECLARE venta INT DEFAULT (SELECT id FROM stock_movement_type WHERE description = 'Venta');
    DECLARE curStock INT DEFAULT (SELECT currentStock(new.article_id));
	    
    IF new.stock_movement_type_id = venta AND new.quantity > curStock THEN
		signal sqlstate '45000' 
        SET MESSAGE_TEXT = 'Trying to oversell!';
    END IF;
END
