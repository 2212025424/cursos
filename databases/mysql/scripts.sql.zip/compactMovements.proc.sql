CREATE DEFINER=`mauro`@`localhost` PROCEDURE `compactMovements`(IN aId INT, OUT qty INT)
Begin
	DECLARE done INT DEFAULT 0;
    DECLARE purchaseId, purchaseQty INT;
    DECLARE purchaseDate DATE;
    DECLARE cur1 CURSOR FOR SELECT id, date, quantity FROM stock_movement WHERE article_id = aId AND stock_movement_type_id = 1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    
    SET qty = 0;
    
    OPEN cur1;
    
    WHILE DONE = 0 DO
		FETCH cur1 INTO purchaseId, purchaseDate, purchaseQty;
        Block2:
        Begin
			DECLARE saleId INT;
			DECLARE done2 INT DEFAULT 0;
            DECLARE cur2 CURSOR FOR SELECT id FROM stock_movement sm WHERE sm.article_id = aId AND sm.stock_movement_type_id = 2 AND sm.date >= purchaseDate AND quantity = purchaseQty;
			DECLARE CONTINUE HANDLER FOR NOT FOUND SET done2 = 1;
        
			OPEN cur2;
        
			FETCH cur2 INTO saleId;
        
			IF saleId THEN
				DELETE FROM stock_movement WHERE id IN (purchaseId, saleId);
				SET qty = qty + ROW_COUNT();
			END IF;
            
			CLOSE cur2;
		END BLOCK2;
    END WHILE;
    
    CLOSE cur1;
END
