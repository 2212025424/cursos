CREATE DEFINER=`mauro`@`localhost` FUNCTION `currentStock`(aId INT) RETURNS int
    READS SQL DATA
BEGIN
	DECLARE compra INT DEFAULT (SELECT id FROM stock_movement_type WHERE description = 'Compra');
    DECLARE venta INT DEFAULT (SELECT id FROM stock_movement_type WHERE description = 'Venta');
	DECLARE comprado INT DEFAULT (SELECT IFNULL(SUM(quantity),0) FROM stock_movement WHERE stock_movement_type_id = compra AND article_id = aId);
    DECLARE vendido INT DEFAULT (SELECT IFNULL(SUM(quantity),0) FROM stock_movement WHERE stock_movement_type_id = venta AND article_id = aId);
    
    
	RETURN (comprado - vendido);
	
END